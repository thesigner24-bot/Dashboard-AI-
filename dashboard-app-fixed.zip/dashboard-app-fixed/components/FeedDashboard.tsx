import React from 'react';
import { ThumbsUp, ThumbsDown, Maximize2, MoreVertical, ChevronDown, ArrowLeft, Activity, Thermometer } from 'lucide-react';

interface FeedDashboardProps {
  mode?: 'live' | 'historical';
  timestamp?: string;
  onBack?: () => void;
}

export const FeedDashboard: React.FC<FeedDashboardProps> = ({ 
  mode = 'live', 
  timestamp = new Date().toISOString(), 
  onBack 
}) => {
  const isLive = mode === 'live';
  const displayTime = isLive 
    ? new Date().toLocaleString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : new Date(timestamp).toLocaleString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Back Button for Historical Mode */}
      {!isLive && onBack && (
        <div className="flex items-center space-x-2 mb-2">
          <button 
            onClick={onBack}
            className="flex items-center px-3 py-1.5 text-sm font-medium text-slate-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to Library
          </button>
          <span className="text-slate-500 text-sm">Viewing Snapshot: {displayTime}</span>
        </div>
      )}

      {/* Top Section: Video + Params + Summary */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* 1. Live/Recorded Feed (Left) - Span 5 */}
        <div className="xl:col-span-5 flex flex-col">
           <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <span className={`flex h-3 w-3 relative`}>
                  <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${isLive ? 'bg-red-400 opacity-75' : 'hidden'}`}></span>
                  <span className={`relative inline-flex rounded-full h-3 w-3 ${isLive ? 'bg-red-500' : 'bg-slate-400'}`}></span>
                </span>
                <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wide">{isLive ? 'Live Feed' : 'Recorded Feed'}</h2>
              </div>
              <span className="text-xs text-slate-500">Last updated: {displayTime}</span>
           </div>
           
           <div className="relative aspect-video bg-black rounded-xl overflow-hidden shadow-sm border border-slate-800 group">
              {/* Simulated Video Content */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-800 via-slate-950 to-black opacity-80"></div>
              {/* Heatmap-like overlay effect */}
              <div className="absolute inset-0 opacity-40 mix-blend-overlay" style={{ background: 'radial-gradient(circle at 30% 40%, rgba(255,0,0,0.4), transparent 40%), radial-gradient(circle at 70% 60%, rgba(0,0,255,0.4), transparent 40%)'}}></div>
              
              {/* Overlay Text */}
              <div className="absolute top-4 left-4 font-mono text-white/80 text-sm">
                {displayTime.replace(/\//g, '-')}
              </div>
              <div className="absolute bottom-4 right-12 font-mono text-white/80 text-sm">
                Camera 01
              </div>
              <button className="absolute bottom-3 right-3 p-1.5 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded backdrop-blur-sm transition-colors">
                <Maximize2 className="w-4 h-4" />
              </button>
           </div>
        </div>

        {/* 2. Detailed Parameters (Middle) - Span 3 */}
        <div className="xl:col-span-3 flex flex-col">
            <div className="flex items-center space-x-2 mb-2">
               <Activity className="w-4 h-4 text-blue-600" />
               <h2 className="text-sm font-bold text-slate-800">Detailed Parameters</h2>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 h-full flex flex-col gap-4">
               {/* Gauge Section */}
               <div className="flex gap-4">
                  <div className="flex-1 bg-slate-50 rounded-lg p-3 border border-slate-100 flex flex-col items-center justify-center">
                     <span className="text-xs font-semibold text-slate-700 mb-2">Hot Index</span>
                     <div className="relative h-32 w-12 bg-slate-200 rounded-full border border-slate-300 overflow-hidden flex items-end justify-center p-1">
                        {/* Gauge Tick Marks */}
                        <div className="absolute right-0 top-0 bottom-0 w-full flex flex-col justify-between py-2 px-1">
                           {[5.00, 3.75, 2.50, 1.25, 0.00].map(val => (
                             <div key={val} className="w-full border-t border-slate-400/30 text-[8px] text-right pr-1 text-slate-400 font-mono">{val.toFixed(2)}</div>
                           ))}
                        </div>
                        {/* Fill */}
                        <div className="w-full bg-gradient-to-t from-blue-400 to-red-400 rounded-b-full relative transition-all duration-1000" style={{ height: '36%' }}>
                           {/* Value Tag */}
                           <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow-sm whitespace-nowrap">
                              1.83
                           </div>
                        </div>
                     </div>
                  </div>

                  <div className="flex-1 flex flex-col gap-3">
                     {/* Health Status */}
                     <div className="bg-blue-50/50 rounded-lg p-3 border border-blue-100">
                        <span className="text-xs font-semibold text-blue-900 block mb-2">Health Status</span>
                        <div className="flex items-center gap-2 mb-2">
                           <div className="w-4 h-4 rounded bg-green-500 shadow-sm"></div>
                           <span className="text-sm font-bold text-slate-800">Healthy</span>
                        </div>
                        <div className="flex gap-1">
                           <button className="p-1 text-slate-400 hover:text-blue-600 transition-colors"><ThumbsUp className="w-4 h-4" /></button>
                           <button className="p-1 text-slate-400 hover:text-red-600 transition-colors"><ThumbsDown className="w-4 h-4" /></button>
                        </div>
                     </div>
                     
                     {/* Process Params Table */}
                     <div className="bg-slate-50 rounded-lg p-3 border border-slate-100 flex-1 flex flex-col justify-center gap-2">
                        <div className="flex justify-between items-center text-xs">
                           <span className="text-slate-500">Torque HO 2</span>
                           <span className="font-mono font-bold text-slate-700">38.21</span>
                        </div>
                         <div className="flex justify-between items-center text-xs">
                           <span className="text-slate-500">NOX entrada</span>
                           <span className="font-mono font-bold text-slate-700">-30.64</span>
                        </div>
                         <div className="flex justify-between items-center text-xs">
                           <span className="text-slate-500">T in calcinador</span>
                           <span className="font-mono font-bold text-slate-700">706.95</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        </div>

        {/* 3. Summary (Right) - Span 4 */}
        <div className="xl:col-span-4 flex flex-col">
            <div className="flex items-center space-x-2 mb-2">
               <MoreVertical className="w-4 h-4 text-slate-400 rotate-90" />
               <h2 className="text-sm font-bold text-slate-800">Summary</h2>
            </div>
            
            <div className="grid grid-cols-2 gap-3 h-full">
               <SummaryCard label="Average Value Of Torque Ho2 Since Past Hour" value="37.61" />
               <SummaryCard label="% Hot Value Of Kiln Since Past Hour" value="6.82" />
               <SummaryCard label="Average Value Of Nox Entrada Ho2 Since Past Hour" value="-18.94" />
               <SummaryCard label="Average Value Of Hot Index Since Past Hour" value="2.00" />
            </div>
        </div>

      </div>

      {/* Bottom Section: Trend Chart */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
         <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
            <div className="flex items-center space-x-2">
               <div className="w-5 h-5 bg-yellow-400 rounded flex items-center justify-center text-white">
                  <Activity className="w-3 h-3" />
               </div>
               <h3 className="font-bold text-slate-800">Past 24hr Trend</h3>
            </div>
            
            <div className="flex items-center space-x-4">
               <div className="relative">
                  <button className="flex items-center space-x-2 text-sm text-slate-600 border border-slate-200 rounded-lg px-3 py-1.5 hover:bg-slate-50">
                     <span>30min Rolling Average</span>
                     <ChevronDown className="w-4 h-4 text-slate-400" />
                  </button>
               </div>
            </div>
         </div>

         {/* Legend */}
         <div className="flex flex-wrap gap-x-4 gap-y-2 mb-4 text-[10px] sm:text-xs text-slate-600 justify-end">
            <LegendItem color="bg-red-500" label="Hot Index" />
            <LegendItem color="bg-purple-600" label="T In Calcinador" />
            <LegendItem color="bg-yellow-500" label="T Air Secudario" />
            <LegendItem color="bg-amber-700" label="Flujo Carbon Calcinador" />
            <LegendItem color="bg-indigo-500" label="Flujo Carbon Horno" />
            <LegendItem color="bg-green-500" label="Torque Ho 2" />
            <LegendItem color="bg-orange-500" label="Nox Entrada Ho 2" />
            <LegendItem color="bg-slate-500" label="Flujo Alimentacion Horno" />
            <button className="ml-2 text-slate-400 underline decoration-slate-300 hover:text-slate-600">Reset Zoom</button>
         </div>

         {/* Chart Area */}
         <div className="relative w-full h-64 bg-slate-50 border-l border-b border-slate-200">
            {/* Grid Lines */}
            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
               {[...Array(5)].map((_, i) => <div key={i} className="w-full h-px bg-slate-200/50"></div>)}
            </div>

            {/* Simulated Chart Paths - These are static SVG paths for aesthetics */}
            <svg className="absolute inset-0 w-full h-full p-1" viewBox="0 0 1000 200" preserveAspectRatio="none">
               <path d="M0,150 C50,140 100,60 150,50 C200,40 250,90 300,80 C350,70 400,20 450,100 C500,180 550,120 600,130 C650,140 700,60 750,50 C800,40 850,90 900,80 C950,70 1000,20 1000,100" fill="none" stroke="#ef4444" strokeWidth="2" />
               <path d="M0,100 C100,100 200,50 300,150 C400,250 500,50 600,100 C700,150 800,100 900,150 L1000,120" fill="none" stroke="#9333ea" strokeWidth="2" />
               <path d="M0,180 C150,180 200,160 300,160 C400,160 500,100 600,140 C700,180 800,80 900,100 L1000,60" fill="none" stroke="#eab308" strokeWidth="2" />
               <path d="M0,20 C100,30 200,20 300,40 C400,60 500,150 600,140 C700,130 800,160 900,150 L1000,180" fill="none" stroke="#22c55e" strokeWidth="2" opacity="0.7" />
            </svg>
            
            {/* X Axis Labels */}
            <div className="absolute bottom-[-24px] left-0 right-0 flex justify-between text-[10px] text-slate-400 font-medium px-2">
               <span>3PM</span>
               <span>6PM</span>
               <span>9PM</span>
               <span>12AM</span>
               <span>3AM</span>
               <span>6AM</span>
               <span>9AM</span>
               <span>12PM</span>
            </div>
         </div>
      </div>
    </div>
  );
};

const SummaryCard = ({ label, value }: { label: string, value: string }) => (
   <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex flex-col justify-between hover:bg-white hover:shadow-md transition-all">
      <span className="text-[10px] sm:text-xs text-slate-500 font-medium leading-tight mb-2 text-center">{label}</span>
      <span className="text-2xl sm:text-3xl font-bold text-slate-700 text-center tracking-tight">{value}</span>
   </div>
);

const LegendItem = ({ color, label }: { color: string, label: string }) => (
   <div className="flex items-center space-x-1.5">
      <div className={`w-2 h-2 rounded-full ${color}`}></div>
      <span>{label}</span>
   </div>
);