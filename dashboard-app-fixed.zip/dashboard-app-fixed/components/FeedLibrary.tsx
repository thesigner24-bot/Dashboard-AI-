import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Maximize2, Info, Download, Image as ImageIcon, AlertTriangle, Filter, ArrowLeft } from 'lucide-react';
import { FeedDashboard } from './FeedDashboard';

interface FeedItem {
  id: number;
  camera: string;
  hasAlert: boolean;
  date: string;
  time: string;
  timestamp: string;
}

export const FeedLibrary: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'photo' | 'video'>('photo');
  const [selectedFeed, setSelectedFeed] = useState<FeedItem | null>(null);

  // Mock data
  const feedItems: FeedItem[] = Array(12).fill(null).map((_, i) => {
    const min = 54 - i;
    const time = `14:${min}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`;
    return {
      id: i,
      camera: 'CamJ31c1',
      hasAlert: i % 3 === 0, // Some have alerts
      date: '15/02/2026',
      time: time,
      timestamp: `2026-02-15T${time}:00`,
    };
  });

  if (selectedFeed) {
    return (
      <FeedDashboard 
        mode="historical" 
        timestamp={selectedFeed.timestamp} 
        onBack={() => setSelectedFeed(null)} 
      />
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 min-h-[600px] flex flex-col animate-fadeIn">
       {/* Sub Navigation (Photo / Video Gallery) */}
       <div className="flex items-center px-6 border-b border-slate-200">
         <button
           onClick={() => setActiveSubTab('photo')}
           className={`py-4 mr-8 text-sm font-medium border-b-2 transition-colors focus:outline-none ${
             activeSubTab === 'photo' 
             ? 'border-blue-600 text-blue-600' 
             : 'border-transparent text-slate-500 hover:text-slate-800'
           }`}
         >
           Photo gallery
         </button>
         <button
           onClick={() => setActiveSubTab('video')}
           className={`py-4 text-sm font-medium border-b-2 transition-colors focus:outline-none ${
             activeSubTab === 'video' 
             ? 'border-blue-600 text-blue-600' 
             : 'border-transparent text-slate-500 hover:text-slate-800'
           }`}
         >
           Video gallery
         </button>
       </div>

       {/* Filter Bar */}
       <div className="p-4 sm:p-6 border-b border-slate-100 flex flex-col xl:flex-row xl:items-center gap-4 bg-slate-50/50">
          <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto">
            <Select placeholder="Angul" />
            <Select placeholder="CamJ31c1" />
            <Select placeholder="Today" />
            <Select placeholder="All frames" />
            <Select placeholder="Original image" />
            
            <button className="px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium rounded-md transition-colors shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
              Apply
            </button>
          </div>

          <div className="xl:ml-auto flex items-center justify-between xl:justify-end w-full xl:w-auto text-sm text-slate-500 space-x-4">
             <span>1-12 of 845</span>
             <div className="flex items-center space-x-1">
                <button className="p-1 hover:bg-slate-200 rounded text-slate-400 hover:text-slate-600">
                    <ChevronLeft className="w-5 h-5" />
                </button>
                <button className="p-1 hover:bg-slate-200 rounded text-slate-400 hover:text-slate-600">
                    <ChevronRight className="w-5 h-5" />
                </button>
             </div>
          </div>
       </div>

       {/* Grid Content */}
       <div className="p-6 bg-slate-50 flex-1">
          <h2 className="text-lg font-medium text-slate-800 mb-4 px-1">Angul</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {feedItems.map((item) => (
               <FeedCard 
                 key={item.id} 
                 item={item} 
                 onClick={() => setSelectedFeed(item)} 
               />
            ))}
          </div>
       </div>
    </div>
  );
};

// Helper Components

const Select = ({ placeholder }: { placeholder: string }) => (
  <div className="relative group">
    <select className="appearance-none bg-white border border-slate-300 hover:border-slate-400 text-slate-700 py-2 pl-4 pr-10 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent cursor-pointer min-w-[140px] shadow-sm transition-colors">
       <option>{placeholder}</option>
    </select>
    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
      <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
    </div>
  </div>
);

const FeedCard = ({ item, onClick }: { item: FeedItem; onClick: () => void }) => (
   <div 
     onClick={onClick}
     className="group relative aspect-video bg-slate-900 rounded-lg overflow-hidden shadow-sm border border-slate-200 hover:border-blue-400 hover:ring-2 hover:ring-blue-500/20 transition-all cursor-pointer"
   >
       {/* Background (simulating coal conveyor belt) */}
       <div className="absolute inset-0 bg-neutral-800">
           {/* Conveyor Belt Texture Simulation */}
           <div className="absolute inset-0 opacity-40 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-600 via-slate-900 to-black"></div>
           <div className="absolute inset-0" style={{ 
               backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 19px, #ffffff10 20px)',
               backgroundSize: '100% 20px'
           }}></div>
           {/* Coal-like noise */}
           <div className="absolute inset-0 opacity-30" style={{ filter: 'contrast(150%) brightness(80%)', backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`}}></div>
           
           {/* Belt Edges */}
           <div className="absolute left-0 top-0 bottom-0 w-8 bg-black/40 border-r border-white/5 backdrop-blur-[1px]"></div>
           <div className="absolute right-0 top-0 bottom-0 w-8 bg-black/40 border-l border-white/5 backdrop-blur-[1px]"></div>
       </div>

       {/* Top Bar Overlay */}
       <div className="absolute top-0 left-0 right-0 p-2 flex justify-between items-start z-10">
          <div className="flex items-center space-x-0.5">
              <span className="bg-white/90 text-slate-900 text-[10px] font-bold px-1.5 py-0.5 rounded-l-sm border-r border-slate-300">
                  {item.camera}
              </span>
              {item.hasAlert && (
                <span className="flex items-center bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-r-sm">
                   <AlertTriangle className="w-3 h-3 mr-1 fill-current" />
                   Alert
                </span>
              )}
          </div>
          
          <div className="flex items-center space-x-1">
             <span className="bg-black/60 backdrop-blur-md text-white/90 text-[10px] font-mono px-1.5 py-0.5 rounded border border-white/10 shadow-sm">
                {item.date} <span className="text-white/60">|</span> {item.time}
             </span>
             <button className="bg-black/40 hover:bg-black/60 text-white p-1 rounded backdrop-blur-sm transition-colors">
                <Info className="w-3.5 h-3.5" />
             </button>
          </div>
       </div>
       
       {/* Maximize Icon */}
       <div className="absolute top-9 left-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
           <button className="p-1 text-white/70 hover:text-white bg-black/20 hover:bg-black/40 rounded transition-colors">
               <Maximize2 className="w-4 h-4" />
           </button>
       </div>

       {/* Bottom Icons Overlay */}
       <div className="absolute bottom-0 left-0 right-0 p-2 flex justify-between items-end z-10 bg-gradient-to-t from-black/80 to-transparent pt-6 translate-y-2 group-hover:translate-y-0 transition-transform">
          <div className="flex space-x-1">
             <div className="p-1 rounded bg-white/10 border border-white/10 backdrop-blur-sm">
                 <ImageIcon className="w-3.5 h-3.5 text-white/90" />
             </div>
          </div>
          <div className="flex space-x-1">
             <button className="p-1 rounded hover:bg-white/20 text-white/80 hover:text-white transition-colors">
                 <Download className="w-4 h-4" />
             </button>
          </div>
       </div>
   </div>
);