import React, { useState } from 'react';
import { ChevronDown, Menu, Bell, User } from 'lucide-react';
import { Tab, Plant, Camera } from '../types';

interface HeaderProps {
  currentTab: Tab;
  onTabChange: (tab: Tab) => void;
  selectedPlant: Plant;
  selectedCamera: Camera;
  plants: Plant[];
  cameras: Camera[];
  onPlantChange: (plant: Plant) => void;
  onCameraChange: (camera: Camera) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  selectedPlant,
  selectedCamera,
  plants,
  cameras,
  onPlantChange,
  onCameraChange
}) => {
  const [plantOpen, setPlantOpen] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-sm">
      <div className="px-6 h-16 flex items-center justify-between">
        {/* Left: Breadcrumbs */}
        <div className="flex items-center text-sm font-medium text-slate-600">
            <span className="text-slate-400 font-normal">Coal Sizing</span>
            <span className="mx-2 text-slate-300">/</span>
            
            {/* Plant Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setPlantOpen(!plantOpen)}
                className="flex items-center hover:bg-slate-100 px-2 py-1 rounded transition-colors text-slate-900 font-semibold"
              >
                {selectedPlant.name}
                <ChevronDown className="ml-1 w-4 h-4 text-slate-400" />
              </button>
              
              {plantOpen && (
                <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-slate-200 rounded-md shadow-lg py-1 z-50">
                  {plants.map(plant => (
                    <button
                      key={plant.id}
                      onClick={() => { onPlantChange(plant); setPlantOpen(false); }}
                      className="block w-full text-left px-4 py-2 hover:bg-slate-50 text-slate-700"
                    >
                      {plant.name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <span className="mx-2 text-slate-300">/</span>

            {/* Camera Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setCameraOpen(!cameraOpen)}
                className="flex items-center hover:bg-slate-100 px-2 py-1 rounded transition-colors text-slate-900 font-semibold"
              >
                {selectedCamera.name}
                <ChevronDown className="ml-1 w-4 h-4 text-slate-400" />
              </button>
               {cameraOpen && (
                <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-slate-200 rounded-md shadow-lg py-1 z-50">
                  {cameras.map(cam => (
                    <button
                      key={cam.id}
                      onClick={() => { onCameraChange(cam); setCameraOpen(false); }}
                      className="block w-full text-left px-4 py-2 hover:bg-slate-50 text-slate-700"
                    >
                      {cam.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
        </div>

        {/* Right: User/System Actions */}
        <div className="flex items-center space-x-4">
          <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
            <Bell className="w-5 h-5" />
          </button>
           <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
            <User className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 flex space-x-8 text-sm border-t border-slate-100">
        {Object.values(Tab).map((tab) => (
          <button
            key={tab}
            onClick={() => onTabChange(tab)}
            className={`py-3 border-b-2 font-medium transition-colors ${
              currentTab === tab
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>
    </header>
  );
};