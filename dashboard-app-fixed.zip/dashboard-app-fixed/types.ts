export interface Alert {
  id: string;
  timestamp: string; // ISO string for sorting, display formatted
  status: 'critical' | 'warning';
  issueType: string;
  message: string;
  validation: 'confirmed' | 'rejected' | null;
  imagePlaceholder?: string; // Color code for placeholder
}

export enum Tab {
  FEED = 'Feed',
  ALERTS = 'Alerts (Active)',
  LIBRARY = 'Feed Library',
  ANALYTICS = 'Analytics',
  REPORT = 'Report'
}

export interface Plant {
  id: string;
  name: string;
}

export interface Camera {
  id: string;
  name: string;
}
